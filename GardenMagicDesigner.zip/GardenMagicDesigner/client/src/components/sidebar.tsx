import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChatRoom, User } from '@shared/schema';
import { useAuth } from '@/hooks/use-auth';
import { Logo } from './logo';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card } from '@/components/ui/card';
import {
  Search,
  PlusCircle,
  Settings,
  Bell,
  LogOut,
  Edit
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface SidebarProps {
  onCreateRoom: () => void;
  onSelectRoom: (room: ChatRoom) => void;
  selectedRoomId?: number;
  className?: string;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  onCreateRoom,
  onSelectRoom,
  selectedRoomId,
  className,
  mobileOpen,
  onCloseMobile
}) => {
  const { user, logoutMutation } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  const { data: rooms = [] } = useQuery<(ChatRoom & { unreadCount?: number })[]>({
    queryKey: ['/api/rooms'],
    enabled: !!user,
  });

  // Filter rooms based on search query
  const filteredRooms = rooms.filter(room => 
    room.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (room.description && room.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Close sidebar on room select in mobile view
  const handleRoomSelect = (room: ChatRoom) => {
    onSelectRoom(room);
    if (window.innerWidth < 768) {
      onCloseMobile();
    }
  };

  // Effect to close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const sidebar = document.getElementById('sidebar');
      const mobileMenuBtn = document.getElementById('mobileMenuBtn');
      
      if (mobileOpen && sidebar && !sidebar.contains(e.target as Node) && 
          mobileMenuBtn && !mobileMenuBtn.contains(e.target as Node)) {
        onCloseMobile();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [mobileOpen, onCloseMobile]);

  // Handle user logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Determine the mobile transform class
  const mobileTransformClass = mobileOpen ? 'translate-x-0' : '-translate-x-full';

  return (
    <aside 
      id="sidebar"
      className={cn(
        "bg-white w-72 h-full transform transition-transform duration-300 ease-in-out fixed md:relative z-30 shadow-lg",
        "md:translate-x-0",
        mobileTransformClass,
        className
      )}
    >
      {/* Logo */}
      <div className="px-6 py-5 border-b border-gray-200">
        <Logo />
      </div>
      
      {/* User Profile Section */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Avatar className="w-12 h-12 border-2 border-primary">
              <AvatarImage src={user?.avatarUrl || ''} alt={user?.displayName} />
              <AvatarFallback>{user?.displayName?.charAt(0) || 'U'}</AvatarFallback>
            </Avatar>
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></span>
          </div>
          <div>
            <h3 className="font-semibold text-gray-800">{user?.displayName}</h3>
            <p className="text-xs text-gray-500">
              <span className="inline-block w-2 h-2 bg-green-500 rounded-full mr-1"></span>
              Online
            </p>
          </div>
        </div>
        <div className="mt-4">
          <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
            <Edit className="h-4 w-4 mr-2" />
            Edit Profile
          </Button>
        </div>
      </div>
      
      {/* Chat Rooms Section */}
      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-semibold text-gray-800">Chat Rooms</h2>
          <Button variant="ghost" size="icon" onClick={onCreateRoom} className="text-primary hover:text-primary-dark">
            <PlusCircle className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Room Search */}
        <div className="relative mb-4">
          <Input
            placeholder="Search rooms..."
            className="w-full bg-gray-100 py-2 pr-10 text-sm focus:ring-2 focus:ring-primary focus:bg-white transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
        </div>
        
        {/* Room List */}
        <ScrollArea className="max-h-[calc(100vh-320px)]">
          <div className="space-y-3">
            {filteredRooms.length > 0 ? (
              filteredRooms.map((room) => (
                <Card 
                  key={room.id}
                  className={cn(
                    "p-3 rounded-lg hover:shadow transition-all cursor-pointer border-l-4",
                    selectedRoomId === room.id ? "border-l-primary-dark" : "border-l-gray-300"
                  )}
                  onClick={() => handleRoomSelect(room)}
                >
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium text-gray-800">{room.name}</h3>
                    {room.unreadCount ? (
                      <span className={cn(
                        "text-xs px-2 py-0.5 rounded-full",
                        selectedRoomId === room.id 
                          ? "bg-primary-light text-white" 
                          : "bg-gray-200 text-gray-700"
                      )}>
                        {room.unreadCount}
                      </span>
                    ) : null}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {room.description || 'No description'}
                  </p>
                </Card>
              ))
            ) : (
              <p className="text-sm text-gray-500 text-center py-4">
                {searchQuery ? 'No rooms match your search' : 'No rooms available'}
              </p>
            )}
          </div>
        </ScrollArea>
      </div>
      
      {/* Settings & Logout */}
      <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-gray-200">
        <div className="flex space-x-4">
          <Button variant="ghost" size="icon" className="text-gray-600 hover:text-primary">
            <Settings className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-gray-600 hover:text-primary">
            <Bell className="h-5 w-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-gray-600 hover:text-red-600 ml-auto"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </aside>
  );
};
