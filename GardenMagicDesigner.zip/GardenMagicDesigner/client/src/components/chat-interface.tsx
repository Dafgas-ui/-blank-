import React, { useState, useRef, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { useWebSocket } from '@/lib/websocket';
import { useQuery, useMutation } from '@tanstack/react-query';
import { ChatRoom, Message, RoomMember, User } from '@shared/schema';
import { format } from 'date-fns';
import { 
  Check, 
  CheckCheck, 
  Phone, 
  Video, 
  Info, 
  Paperclip, 
  Smile, 
  Send,
  Loader2,
  Image
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ChatInterfaceProps {
  room: ChatRoom;
  className?: string;
}

interface MessageWithUser extends Message, Partial<User> {}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ room, className }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { sendMessage, lastMessage } = useWebSocket();
  const [messageContent, setMessageContent] = useState('');
  const [messages, setMessages] = useState<MessageWithUser[]>([]);
  const [typingUsers, setTypingUsers] = useState<Set<number>>(new Set());
  const [isUploading, setIsUploading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Query for room messages
  const { data: initialMessages = [], isLoading: isLoadingMessages } = useQuery<MessageWithUser[]>({
    queryKey: [`/api/rooms/${room.id}/messages`],
    enabled: !!room?.id,
  });
  
  // Query for room members
  const { data: members = [] } = useQuery<(RoomMember & User)[]>({
    queryKey: [`/api/rooms/${room.id}/members`],
    enabled: !!room?.id,
  });
  
  // File upload mutation
  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('image', file);
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Upload failed');
      }
      
      return response.json();
    },
    onSuccess: (data, file) => {
      sendChatMessage(messageContent, data.url);
      setSelectedImage(null);
      setImagePreviewUrl(null);
    },
    onError: (error) => {
      toast({
        title: 'Upload failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Set initial messages when loaded
  useEffect(() => {
    if (initialMessages.length > 0) {
      setMessages(initialMessages);
    }
  }, [initialMessages]);
  
  // Handle WebSocket messages
  useEffect(() => {
    if (!lastMessage || !room) return;
    
    if (lastMessage.type === 'new_message' && lastMessage.payload.roomId === room.id) {
      setMessages(prev => [...prev, lastMessage.payload]);
    } 
    else if (lastMessage.type === 'user_typing' && lastMessage.payload.roomId === room.id) {
      if (lastMessage.payload.userId !== user?.id) {
        setTypingUsers(prev => {
          const newSet = new Set(prev);
          if (lastMessage.payload.isTyping) {
            newSet.add(lastMessage.payload.userId);
          } else {
            newSet.delete(lastMessage.payload.userId);
          }
          return newSet;
        });
      }
    }
  }, [lastMessage, room, user]);
  
  // Join room via WebSocket when room changes
  useEffect(() => {
    if (room && user) {
      sendMessage({
        type: 'join_room',
        payload: { roomId: room.id }
      });
      
      // Cleanup: leave room when component unmounts or room changes
      return () => {
        sendMessage({
          type: 'leave_room',
          payload: { roomId: room.id }
        });
      };
    }
  }, [room?.id, user]);
  
  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  // Send a chat message
  const sendChatMessage = (content: string, imageUrl?: string) => {
    if ((!content.trim() && !imageUrl) || !user || !room) return;
    
    sendMessage({
      type: 'message',
      payload: {
        roomId: room.id,
        content: content.trim(),
        imageUrl
      }
    });
    
    setMessageContent('');
  };
  
  // Handle message submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (selectedImage) {
      setIsUploading(true);
      uploadMutation.mutate(selectedImage);
    } else {
      sendChatMessage(messageContent);
    }
  };
  
  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(file);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Trigger file input click
  const handleAttachmentClick = () => {
    fileInputRef.current?.click();
  };
  
  // Cancel image upload
  const cancelImageUpload = () => {
    setSelectedImage(null);
    setImagePreviewUrl(null);
  };
  
  // Group messages by date
  const messagesByDate: { [key: string]: MessageWithUser[] } = {};
  messages.forEach(message => {
    const date = format(new Date(message.sentAt), 'yyyy-MM-dd');
    if (!messagesByDate[date]) {
      messagesByDate[date] = [];
    }
    messagesByDate[date].push(message);
  });
  
  // Get friendly date label
  const getDateLabel = (dateString: string) => {
    const messageDate = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (messageDate >= today) {
      return 'Today';
    } else if (messageDate >= yesterday) {
      return 'Yesterday';
    } else {
      return format(messageDate, 'MMMM d, yyyy');
    }
  };
  
  return (
    <div className={cn("flex flex-col h-full", className)}>
      {/* Chat Header */}
      <header className="bg-white shadow-sm z-10 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <h2 className="font-semibold text-lg">{room.name}</h2>
          <span className="ml-3 text-xs bg-primary text-white px-2 py-0.5 rounded-full">
            {members.length} {members.length === 1 ? 'member' : 'members'}
          </span>
        </div>
        
        <div className="flex space-x-4">
          <Button variant="ghost" size="icon" className="text-gray-600 hover:text-primary">
            <Phone className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-gray-600 hover:text-primary">
            <Video className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-gray-600 hover:text-primary">
            <Info className="h-5 w-5" />
          </Button>
        </div>
      </header>
      
      {/* Chat Messages */}
      <ScrollArea className="flex-1 p-6 bg-gray-50">
        {isLoadingMessages ? (
          <div className="flex justify-center my-10">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center my-10 text-gray-500">
            <p>No messages yet. Be the first to send a message!</p>
          </div>
        ) : (
          Object.keys(messagesByDate).map(date => (
            <div key={date}>
              <div className="flex justify-center my-4">
                <span className="text-xs bg-gray-200 text-gray-700 px-3 py-1 rounded-full">
                  {getDateLabel(date)}
                </span>
              </div>
              
              {messagesByDate[date].map((message, index) => {
                const isSentByMe = message.userId === user?.id;
                
                return (
                  <div 
                    key={message.id}
                    className={cn(
                      "flex items-start mb-4 max-w-3xl",
                      isSentByMe ? "justify-end ml-auto" : ""
                    )}
                  >
                    {!isSentByMe && (
                      <Avatar className="w-8 h-8 mr-3 mt-1">
                        <AvatarImage src={message.avatarUrl || ''} alt={message.username} />
                        <AvatarFallback>{message.displayName?.charAt(0) || 'U'}</AvatarFallback>
                      </Avatar>
                    )}
                    
                    <div className={isSentByMe ? "flex flex-col items-end" : ""}>
                      <div className="flex items-center mb-1">
                        {!isSentByMe && (
                          <span className="font-medium text-sm text-gray-800 mr-2">
                            {message.displayName}
                          </span>
                        )}
                        <span className="text-xs text-gray-500">
                          {format(new Date(message.sentAt), 'h:mm a')}
                        </span>
                        {isSentByMe && (
                          <span className="font-medium text-sm text-gray-800 ml-2">
                            You
                          </span>
                        )}
                      </div>
                      
                      <div 
                        className={cn(
                          "p-3 rounded-lg shadow-sm",
                          isSentByMe 
                            ? "bg-primary text-white chat-bubble-sent" 
                            : "bg-white chat-bubble-received"
                        )}
                      >
                        <p className={isSentByMe ? "text-white" : "text-gray-800"}>
                          {message.content}
                        </p>
                        
                        {message.imageUrl && (
                          <img 
                            src={message.imageUrl} 
                            alt="Shared image" 
                            className="rounded-lg w-full h-auto mt-2"
                          />
                        )}
                      </div>
                      
                      {isSentByMe && (
                        <div className="flex items-center mt-1">
                          <CheckCheck className="h-3 w-3 text-green-500 mr-1" />
                          <span className="text-xs text-gray-500">Read</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ))
        )}
        
        {/* Typing indicators */}
        {typingUsers.size > 0 && (
          <div className="flex items-start mb-4 max-w-3xl animate-pulse">
            <Avatar className="w-8 h-8 mr-3 mt-1">
              <AvatarFallback>T</AvatarFallback>
            </Avatar>
            <div className="bg-white p-3 rounded-lg shadow-sm chat-bubble-received">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </ScrollArea>
      
      {/* Message Input */}
      <div className="bg-white border-t border-gray-200 p-4">
        <form onSubmit={handleSubmit} className="flex items-end space-x-2">
          <Button 
            type="button" 
            variant="ghost"
            size="icon"
            onClick={handleAttachmentClick}
            className="text-gray-500 hover:text-primary"
          >
            <Paperclip className="h-5 w-5" />
          </Button>
          
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept="image/*"
            onChange={handleFileSelect}
          />
          
          <div className="relative flex-1">
            {imagePreviewUrl && (
              <div className="relative mb-2 p-2 bg-gray-100 rounded-md">
                <div className="flex items-center">
                  <Image className="h-4 w-4 mr-2 text-primary" />
                  <span className="text-sm truncate">{selectedImage?.name}</span>
                  <Button 
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="ml-auto text-gray-500"
                    onClick={cancelImageUpload}
                  >
                    &times;
                  </Button>
                </div>
                <img 
                  src={imagePreviewUrl} 
                  alt="Upload preview" 
                  className="mt-2 max-h-32 rounded-md"
                />
              </div>
            )}
            
            <Textarea
              placeholder="Type your message..."
              className="w-full resize-none min-h-[42px] max-h-32 pr-10"
              value={messageContent}
              onChange={(e) => setMessageContent(e.target.value)}
              disabled={isUploading || uploadMutation.isPending}
              rows={1}
            />
            
            <Button 
              type="button"
              variant="ghost"
              size="icon"
              className="absolute right-2 bottom-2 text-gray-500 hover:text-primary"
            >
              <Smile className="h-5 w-5" />
            </Button>
          </div>
          
          <Button 
            type="submit"
            disabled={(!messageContent.trim() && !selectedImage) || isUploading || uploadMutation.isPending}
            className="bg-gradient-to-r from-primary to-blue-800 text-white p-2.5 rounded-lg shadow-sm hover:shadow-md transition-all"
          >
            {isUploading || uploadMutation.isPending ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Send className="h-5 w-5" />
            )}
          </Button>
        </form>
      </div>
    </div>
  );
};
