import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChatRoom, User, RoomMember } from '@shared/schema';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { format } from 'date-fns';
import { UserPlus, Upload, Download } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RoomDetailsSidebarProps {
  room: ChatRoom;
  className?: string;
}

export const RoomDetailsSidebar: React.FC<RoomDetailsSidebarProps> = ({ room, className }) => {
  // Query for room members
  const { data: members = [] } = useQuery<(RoomMember & User)[]>({
    queryKey: [`/api/rooms/${room.id}/members`],
    enabled: !!room?.id,
  });
  
  // Query for shared files (in a real app, this would be a separate API call)
  const { data: messages = [] } = useQuery({
    queryKey: [`/api/rooms/${room.id}/messages`],
    enabled: !!room?.id,
  });
  
  // Filter messages to only those with images
  const sharedFiles = messages.filter(message => message.imageUrl).map(message => ({
    id: message.id,
    fileName: message.imageUrl?.split('/').pop() || 'file.jpg',
    fileUrl: message.imageUrl,
    fileType: message.imageUrl?.split('.').pop() || 'jpg',
    fileSize: '2.4 MB', // This would come from the server in a real app
    uploadDate: message.sentAt
  }));
  
  // Format creation date
  const formattedCreationDate = room.createdAt 
    ? format(new Date(room.createdAt), 'MMMM d, yyyy')
    : 'Unknown date';
    
  // Get file icon based on file type
  const getFileIcon = (fileType: string) => {
    switch (fileType.toLowerCase()) {
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return <i className="fas fa-file-image text-primary-dark mr-2"></i>;
      case 'pdf':
        return <i className="fas fa-file-alt text-blue-800 mr-2"></i>;
      case 'xlsx':
      case 'xls':
        return <i className="fas fa-file-excel text-green-700 mr-2"></i>;
      default:
        return <i className="fas fa-file text-gray-700 mr-2"></i>;
    }
  };
  
  return (
    <aside className={cn("hidden lg:block bg-white w-72 h-full border-l border-gray-200 overflow-y-auto", className)}>
      <div className="p-6 border-b border-gray-200">
        <h2 className="font-semibold text-lg">Room Details</h2>
      </div>
      
      {/* Room Information */}
      <div className="p-6 border-b border-gray-200">
        <h3 className="font-medium text-gray-800 mb-2">{room.name}</h3>
        <p className="text-sm text-gray-600 mb-4">
          {room.description || 'No description available.'}
        </p>
        <div className="flex items-center text-sm text-gray-600">
          <i className="far fa-calendar-alt mr-2"></i>
          <span>Created on {formattedCreationDate}</span>
        </div>
      </div>
      
      {/* Members List */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-medium text-gray-800">Members ({members.length})</h3>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary-dark">
            <UserPlus className="h-4 w-4 mr-1" />
            Add
          </Button>
        </div>
        
        {/* Member List */}
        <ScrollArea className="h-48">
          <div className="space-y-3">
            {members.map(member => (
              <div key={member.id} className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="w-8 h-8 mr-3">
                    <AvatarImage src={member.avatarUrl || ''} alt={member.displayName} />
                    <AvatarFallback>{member.displayName?.charAt(0) || 'U'}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium text-gray-800">{member.displayName}</p>
                    <p className="text-xs text-gray-500">{member.isAdmin ? 'Admin' : 'Member'}</p>
                  </div>
                </div>
                <div className={cn(
                  "w-2 h-2 rounded-full",
                  member.isOnline ? "bg-green-500" : "bg-gray-300"
                )}></div>
              </div>
            ))}
          </div>
        </ScrollArea>
        
        {members.length > 5 && (
          <Button variant="link" size="sm" className="text-primary hover:text-primary-dark mt-2">
            View all members
          </Button>
        )}
      </div>
      
      {/* Shared Files */}
      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-medium text-gray-800">Shared Files</h3>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary-dark">
            <Upload className="h-4 w-4 mr-1" />
            Upload
          </Button>
        </div>
        
        {/* File List */}
        <ScrollArea className="h-48">
          <div className="space-y-3">
            {sharedFiles.length > 0 ? (
              sharedFiles.slice(0, 10).map(file => (
                <div key={file.id} className="bg-gray-100 p-3 rounded-md flex items-center justify-between">
                  <div className="flex items-center">
                    {getFileIcon(file.fileType)}
                    <div className="max-w-[150px]">
                      <p className="text-sm font-medium text-gray-800 truncate">{file.fileName}</p>
                      <p className="text-xs text-gray-500">
                        {file.fileSize} · {format(new Date(file.uploadDate), 'MMM d')}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="text-gray-600 hover:text-primary-dark">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500 text-center">No files shared yet</p>
            )}
          </div>
        </ScrollArea>
        
        {sharedFiles.length > 10 && (
          <Button variant="link" size="sm" className="text-primary hover:text-primary-dark mt-2">
            View all files
          </Button>
        )}
      </div>
    </aside>
  );
};
