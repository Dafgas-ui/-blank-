import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={className}>
      <h1 className="text-2xl font-bold">
        <span className="gradient-text">Effortless</span>
      </h1>
      <p className="text-sm text-gray-500">Communication Made Simple</p>
    </div>
  );
};
