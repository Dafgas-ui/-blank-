import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { ChatRoom } from '@shared/schema';
import { Sidebar } from '@/components/sidebar';
import { ChatInterface } from '@/components/chat-interface';
import { RoomDetailsSidebar } from '@/components/room-details';
import { CreateRoomModal } from '@/components/create-room-modal';
import { Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';

export default function HomePage() {
  const { user } = useAuth();
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null);
  const [createRoomOpen, setCreateRoomOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  
  // Query for user's rooms
  const { data: rooms = [] } = useQuery<ChatRoom[]>({
    queryKey: ['/api/rooms'],
    enabled: !!user,
  });
  
  // Select the first room by default if none is selected
  useEffect(() => {
    if (!selectedRoom && rooms.length > 0) {
      setSelectedRoom(rooms[0]);
    }
  }, [rooms, selectedRoom]);
  
  // Handle room selection
  const handleSelectRoom = (room: ChatRoom) => {
    setSelectedRoom(room);
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      {/* Mobile Menu Button */}
      <div className="fixed top-4 left-4 z-40 md:hidden">
        <Button 
          id="mobileMenuBtn" 
          variant="outline"
          size="icon"
          className="bg-white p-2 rounded-md shadow-md"
          onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
        >
          <Menu className="h-5 w-5 text-primary" />
        </Button>
      </div>
      
      {/* Sidebar */}
      <Sidebar
        onCreateRoom={() => setCreateRoomOpen(true)}
        onSelectRoom={handleSelectRoom}
        selectedRoomId={selectedRoom?.id}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        {selectedRoom ? (
          <ChatInterface room={selectedRoom} />
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center p-8">
              <h2 className="text-2xl font-bold mb-2">Welcome to Effortless Chat</h2>
              <p className="text-gray-600 mb-6">Select a room to start chatting or create a new one.</p>
              <Button onClick={() => setCreateRoomOpen(true)} className="bg-gradient-to-r from-primary to-blue-800">
                Create Your First Room
              </Button>
            </div>
          </div>
        )}
      </main>
      
      {/* Room Details Sidebar */}
      {selectedRoom && <RoomDetailsSidebar room={selectedRoom} />}
      
      {/* Create Room Modal */}
      <CreateRoomModal 
        open={createRoomOpen} 
        onOpenChange={setCreateRoomOpen} 
      />
      
      {/* Mobile notification toast */}
      <div id="notificationToast" className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white px-4 py-2 rounded-lg shadow-lg z-50 hidden">
        <div className="flex items-center">
          <i className="fas fa-bell mr-2"></i>
          <span id="notificationMessage">New message received</span>
        </div>
      </div>
    </div>
  );
}
