import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { WebSocketMessage, User } from '@shared/schema';
import { storage } from './storage';

interface ExtendedWebSocket extends WebSocket {
  userId?: number;
  roomIds?: Set<number>;
  isAlive?: boolean;
}

export class ChatWebSocketServer {
  private wss: WebSocketServer;
  private clients: Map<number, Set<ExtendedWebSocket>> = new Map();
  private roomSubscriptions: Map<number, Set<ExtendedWebSocket>> = new Map();

  constructor(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/ws' });
    this.initialize();
  }

  private initialize() {
    this.wss.on('connection', (ws: ExtendedWebSocket) => {
      ws.isAlive = true;
      ws.roomIds = new Set();
      
      // Handle ping-pong for connection health check
      ws.on('pong', () => {
        ws.isAlive = true;
      });

      ws.on('message', async (data: string) => {
        try {
          const message: WebSocketMessage = JSON.parse(data);
          
          switch (message.type) {
            case 'user_status':
              await this.handleUserStatus(ws, message.payload);
              break;
            
            case 'join_room':
              await this.handleJoinRoom(ws, message.payload);
              break;
            
            case 'leave_room':
              await this.handleLeaveRoom(ws, message.payload);
              break;
            
            case 'message':
              await this.handleChatMessage(ws, message.payload);
              break;
          }
        } catch (error) {
          console.error('WebSocket message error:', error);
          ws.send(JSON.stringify({
            type: 'error',
            payload: { message: 'Invalid message format' }
          }));
        }
      });

      ws.on('close', async () => {
        if (ws.userId) {
          // Update user status to offline when disconnected
          await storage.updateUserStatus(ws.userId, false);
          
          // Remove client from all rooms
          if (ws.roomIds) {
            for (const roomId of ws.roomIds) {
              this.removeFromRoom(ws, roomId);
            }
          }
          
          // Remove from clients map
          const userClients = this.clients.get(ws.userId);
          if (userClients) {
            userClients.delete(ws);
            if (userClients.size === 0) {
              this.clients.delete(ws.userId);
              
              // Broadcast user offline status
              this.broadcastUserStatus(ws.userId, false);
            }
          }
        }
      });
    });

    // Set up interval to check for dead connections
    setInterval(() => {
      this.wss.clients.forEach((ws: ExtendedWebSocket) => {
        if (ws.isAlive === false) return ws.terminate();
        
        ws.isAlive = false;
        ws.ping();
      });
    }, 30000);
  }

  private async handleUserStatus(ws: ExtendedWebSocket, payload: { userId: number; isOnline: boolean }) {
    const { userId, isOnline } = payload;
    
    // Associate this connection with the user
    ws.userId = userId;
    
    // Add to clients map
    if (!this.clients.has(userId)) {
      this.clients.set(userId, new Set());
    }
    this.clients.get(userId)?.add(ws);
    
    // Update user status in storage
    await storage.updateUserStatus(userId, isOnline);
    
    // Broadcast user status to all relevant rooms
    this.broadcastUserStatus(userId, isOnline);
  }

  private async handleJoinRoom(ws: ExtendedWebSocket, payload: { roomId: number }) {
    const { roomId } = payload;
    
    if (!ws.userId) {
      return ws.send(JSON.stringify({
        type: 'error',
        payload: { message: 'User not authenticated' }
      }));
    }
    
    // Add to room subscriptions
    if (!this.roomSubscriptions.has(roomId)) {
      this.roomSubscriptions.set(roomId, new Set());
    }
    this.roomSubscriptions.get(roomId)?.add(ws);
    
    // Add room to client's subscribed rooms
    ws.roomIds?.add(roomId);
    
    // Get room details and send to client
    const room = await storage.getRoomById(roomId);
    if (room) {
      // Send room details to the client
      ws.send(JSON.stringify({
        type: 'room_joined',
        payload: { room }
      }));
      
      // Load and send room messages
      const messages = await storage.getRoomMessages(roomId);
      ws.send(JSON.stringify({
        type: 'message_history',
        payload: { roomId, messages }
      }));
      
      // Notify others in the room
      this.broadcastToRoom(roomId, {
        type: 'user_joined',
        payload: { roomId, userId: ws.userId }
      }, ws);
    }
  }

  private async handleLeaveRoom(ws: ExtendedWebSocket, payload: { roomId: number }) {
    const { roomId } = payload;
    
    if (!ws.userId) return;
    
    this.removeFromRoom(ws, roomId);
    
    // Notify others in the room
    this.broadcastToRoom(roomId, {
      type: 'user_left',
      payload: { roomId, userId: ws.userId }
    });
  }

  private async handleChatMessage(ws: ExtendedWebSocket, payload: { 
    roomId: number; 
    content: string;
    imageUrl?: string; 
  }) {
    const { roomId, content, imageUrl } = payload;
    
    if (!ws.userId) {
      return ws.send(JSON.stringify({
        type: 'error',
        payload: { message: 'User not authenticated' }
      }));
    }
    
    // Store message in database
    const message = await storage.createMessage({
      roomId,
      userId: ws.userId,
      content,
      imageUrl: imageUrl || null
    });
    
    // Get user details
    const user = await storage.getUser(ws.userId);
    
    if (!user) return;
    
    // Broadcast message to all clients in the room
    this.broadcastToRoom(roomId, {
      type: 'new_message',
      payload: {
        ...message,
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl
      }
    });
  }

  private removeFromRoom(ws: ExtendedWebSocket, roomId: number) {
    // Remove from room subscriptions
    const roomClients = this.roomSubscriptions.get(roomId);
    if (roomClients) {
      roomClients.delete(ws);
      if (roomClients.size === 0) {
        this.roomSubscriptions.delete(roomId);
      }
    }
    
    // Remove from client's room set
    ws.roomIds?.delete(roomId);
  }

  private broadcastToRoom(roomId: number, message: WebSocketMessage, excludeClient?: ExtendedWebSocket) {
    const clients = this.roomSubscriptions.get(roomId);
    if (!clients) return;
    
    const messageStr = JSON.stringify(message);
    
    clients.forEach(client => {
      if (client !== excludeClient && client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }

  private broadcastUserStatus(userId: number, isOnline: boolean) {
    // Find all rooms this user is part of
    Array.from(this.roomSubscriptions.keys()).forEach(roomId => {
      this.broadcastToRoom(roomId, {
        type: 'user_status',
        payload: { userId, isOnline }
      });
    });
  }
}
