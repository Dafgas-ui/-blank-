import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { ChatWebSocketServer } from "./websocket";
import { insertChatRoomSchema, insertRoomMemberSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage_config = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage_config,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!allowedTypes.includes(file.mimetype)) {
      return cb(new Error('Only .jpeg, .png and .gif formats are allowed'));
    }
    cb(null, true);
  }
});

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: any) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized: Please log in" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Serve uploaded files
  app.use('/uploads', express.static(uploadsDir));

  // Chat room routes
  app.get("/api/rooms", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const userRooms = await storage.getUserRooms(userId);
      res.json(userRooms);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rooms" });
    }
  });

  app.post("/api/rooms", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertChatRoomSchema.parse({
        ...req.body,
        createdById: req.user!.id
      });
      
      const newRoom = await storage.createRoom(validatedData);
      res.status(201).json(newRoom);
    } catch (error) {
      res.status(400).json({ message: "Invalid room data" });
    }
  });

  app.get("/api/rooms/:roomId", isAuthenticated, async (req, res) => {
    try {
      const roomId = parseInt(req.params.roomId);
      const room = await storage.getRoomById(roomId);
      
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }
      
      res.json(room);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch room" });
    }
  });

  app.get("/api/rooms/:roomId/members", isAuthenticated, async (req, res) => {
    try {
      const roomId = parseInt(req.params.roomId);
      const members = await storage.getRoomMembers(roomId);
      
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch room members" });
    }
  });

  app.post("/api/rooms/:roomId/members", isAuthenticated, async (req, res) => {
    try {
      const roomId = parseInt(req.params.roomId);
      
      const validatedData = insertRoomMemberSchema.parse({
        ...req.body,
        roomId
      });
      
      const newMember = await storage.addRoomMember(validatedData);
      res.status(201).json(newMember);
    } catch (error) {
      res.status(400).json({ message: "Invalid member data" });
    }
  });

  app.delete("/api/rooms/:roomId/members/:userId", isAuthenticated, async (req, res) => {
    try {
      const roomId = parseInt(req.params.roomId);
      const userId = parseInt(req.params.userId);
      
      await storage.removeRoomMember(roomId, userId);
      res.status(200).json({ message: "Member removed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove member" });
    }
  });

  app.get("/api/rooms/:roomId/messages", isAuthenticated, async (req, res) => {
    try {
      const roomId = parseInt(req.params.roomId);
      const messages = await storage.getRoomMessages(roomId);
      
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // File upload route
  app.post("/api/upload", isAuthenticated, upload.single('image'), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }
    
    const filePath = `/uploads/${req.file.filename}`;
    res.json({ 
      url: filePath,
      filename: req.file.filename
    });
  });

  const httpServer = createServer(app);

  // Initialize WebSocket server
  new ChatWebSocketServer(httpServer);

  return httpServer;
}

import express from "express";
