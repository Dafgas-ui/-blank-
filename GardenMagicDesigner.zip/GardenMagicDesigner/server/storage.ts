import {
  users, type User, type InsertUser,
  chatRooms, type ChatRoom, type InsertChatRoom,
  roomMembers, type RoomMember, type InsertRoomMember,
  messages, type Message, type InsertMessage
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(id: number, isOnline: boolean): Promise<User | undefined>;
  
  // Room operations
  getRooms(): Promise<ChatRoom[]>;
  getRoomById(id: number): Promise<ChatRoom | undefined>;
  createRoom(room: InsertChatRoom): Promise<ChatRoom>;
  
  // Room member operations
  getRoomMembers(roomId: number): Promise<(RoomMember & User)[]>;
  getUserRooms(userId: number): Promise<(RoomMember & ChatRoom)[]>;
  addRoomMember(member: InsertRoomMember): Promise<RoomMember>;
  removeRoomMember(roomId: number, userId: number): Promise<void>;
  
  // Message operations
  getRoomMessages(roomId: number): Promise<(Message & User)[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private rooms: Map<number, ChatRoom>;
  private roomMembers: Map<number, RoomMember>;
  private messages: Map<number, Message>;
  private userIdCounter: number;
  private roomIdCounter: number;
  private memberIdCounter: number;
  private messageIdCounter: number;
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.rooms = new Map();
    this.roomMembers = new Map();
    this.messages = new Map();
    this.userIdCounter = 1;
    this.roomIdCounter = 1;
    this.memberIdCounter = 1;
    this.messageIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id, isOnline: false };
    this.users.set(id, user);
    return user;
  }

  async updateUserStatus(id: number, isOnline: boolean): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (user) {
      user.isOnline = isOnline;
      this.users.set(id, user);
      return user;
    }
    return undefined;
  }

  // Room operations
  async getRooms(): Promise<ChatRoom[]> {
    return Array.from(this.rooms.values());
  }

  async getRoomById(id: number): Promise<ChatRoom | undefined> {
    return this.rooms.get(id);
  }

  async createRoom(insertRoom: InsertChatRoom): Promise<ChatRoom> {
    const id = this.roomIdCounter++;
    const now = new Date();
    const room: ChatRoom = { ...insertRoom, id, createdAt: now };
    this.rooms.set(id, room);
    
    // Automatically add the creator as an admin member
    await this.addRoomMember({
      roomId: id,
      userId: insertRoom.createdById,
      isAdmin: true
    });
    
    return room;
  }

  // Room member operations
  async getRoomMembers(roomId: number): Promise<(RoomMember & User)[]> {
    const members = Array.from(this.roomMembers.values()).filter(
      (member) => member.roomId === roomId
    );
    
    return Promise.all(
      members.map(async (member) => {
        const user = await this.getUser(member.userId);
        return { ...member, ...user! };
      })
    );
  }

  async getUserRooms(userId: number): Promise<(RoomMember & ChatRoom)[]> {
    const memberships = Array.from(this.roomMembers.values()).filter(
      (member) => member.userId === userId
    );
    
    return Promise.all(
      memberships.map(async (member) => {
        const room = await this.getRoomById(member.roomId);
        return { ...member, ...room! };
      })
    );
  }

  async addRoomMember(insertMember: InsertRoomMember): Promise<RoomMember> {
    const id = this.memberIdCounter++;
    const now = new Date();
    const member: RoomMember = { ...insertMember, id, joinedAt: now };
    this.roomMembers.set(id, member);
    return member;
  }

  async removeRoomMember(roomId: number, userId: number): Promise<void> {
    const memberId = Array.from(this.roomMembers.entries()).find(
      ([_, member]) => member.roomId === roomId && member.userId === userId
    )?.[0];
    
    if (memberId) {
      this.roomMembers.delete(memberId);
    }
  }

  // Message operations
  async getRoomMessages(roomId: number): Promise<(Message & User)[]> {
    const roomMessages = Array.from(this.messages.values())
      .filter((message) => message.roomId === roomId)
      .sort((a, b) => a.sentAt.getTime() - b.sentAt.getTime());
    
    return Promise.all(
      roomMessages.map(async (message) => {
        const user = await this.getUser(message.userId);
        return { ...message, ...user! };
      })
    );
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const now = new Date();
    const message: Message = { ...insertMessage, id, sentAt: now };
    this.messages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
